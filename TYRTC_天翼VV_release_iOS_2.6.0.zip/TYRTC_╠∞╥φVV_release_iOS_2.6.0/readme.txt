请开发者在开发前阅读以下内容：
1、此VV源码中，集成RTCSDK的相关代码位于ViewController.m文件，做重点参考。其他文件代码为界面相关，可略读。
2、工程文件介绍：会话界面见RecentView，群组界面见GroupView，设置界面见InfoView，通话界面见CCallingViewController。
3、编译方法：导入RTCSDK文件后，可直接编译运行。
4、详细的接口参数说明及常见问题请参考开发手册。