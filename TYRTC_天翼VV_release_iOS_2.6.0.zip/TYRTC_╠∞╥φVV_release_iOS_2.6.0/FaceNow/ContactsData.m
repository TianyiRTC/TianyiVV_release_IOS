//
//  ContactsData.m
//  FaceNow
//
//  Created by administration on 14-9-30.
//  Copyright (c) 2014年 FaceNow. All rights reserved.
//

#import "ContactsData.h"

@implementation ContactsData

@end
