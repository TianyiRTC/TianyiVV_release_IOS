//
//  MyCustomTableViewCell.h
//  FaceNow
//
//  Created by administration on 14/11/14.
//  Copyright (c) 2014年 FaceNow. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyCustomTableViewCell : UITableViewCell

@end
