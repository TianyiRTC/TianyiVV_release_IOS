//
//  PersonalDetailTableViewController.h
//  FaceNow
//
//  Created by administration on 14-10-15.
//  Copyright (c) 2014年 FaceNow. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PersonalDetailTableViewController : UITableViewController
@property (nonatomic, retain) NSString*   phoneNum;
@end
