//
//  AudioCodecTableViewController.h
//  FaceNow
//
//  Created by administration on 14/11/4.
//  Copyright (c) 2014年 FaceNow. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VersionViewController : UIViewController<UINavigationControllerDelegate>

@end
