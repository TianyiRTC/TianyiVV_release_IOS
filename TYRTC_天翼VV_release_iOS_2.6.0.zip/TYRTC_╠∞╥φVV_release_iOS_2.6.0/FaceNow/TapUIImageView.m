//
//  TapUIImageView.m
//  FaceNow
//
//  Created by administration on 14/10/22.
//  Copyright (c) 2014年 FaceNow. All rights reserved.
//

#import "TapUIImageView.h"

@implementation TapUIImageView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
