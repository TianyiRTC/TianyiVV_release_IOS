//
//  TapUIImageView.h
//  FaceNow
//
//  Created by administration on 14/10/22.
//  Copyright (c) 2014年 FaceNow. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TapUIImageView : UIImageView

@end
